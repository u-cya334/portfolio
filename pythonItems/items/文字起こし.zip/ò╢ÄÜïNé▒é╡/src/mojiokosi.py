import speech_recognition as sr 
import sys
import os
import pydub
import time
import textwrap

r = sr.Recognizer()

audiofile = input("ここにファイルをドロップしてね")
print(audiofile)

name = str(audiofile)
print(name)
if audiofile.endswith(".wav"):
    print('wavファイル')
if audiofile.endswith('.mp3'):
    print('mp3ファイル')
    sound = pydub.AudioSegment.from_mp3(audiofile)
    sound.export(name+".wav", format="wav")
    audiofile =name+'.wav'

f = open(name+'.txt','w')

with sr.AudioFile(audiofile) as source:
    while True:
        audio_data = r.listen(source)
        flac_data = audio_data.get_flac_data(
            convert_rate=None if audio_data.sample_rate >= 8000 else 8000,  # audio samples must be at least 8 kHz
            convert_width=2  # audio samples must be 16-bit
        )
        try:
            print(r.recognize_google(audio_data, language='ja-JP'))
            txt = r.recognize_google(audio_data, language='ja-JP')
            txt = textwrap.wrap(txt,40)

            f.write('\n'.join(txt))
        except sr.UnknownValueError:
            print("読み込めません") # セグメントによっては音声認識できない、無視
        if len(flac_data) == 0: # ファイルの終わり
            break
        time.sleep(1) 

f.close()
 
